import { Component, OnInit } from "@angular/core";
import { FormBuilder } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"]
})
export class LoginComponent implements OnInit {
  r_Fields;
  isNew: boolean = true;
  index = "new";
  logDetail = {
    uname: "",
    pass: ""
  };
  logForm;
  flag = true;
  vflag = true;
  alertText = "";
  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  onSubmit(formData) {
    for (let i in formData) {
      if (formData[i] == "" || formData[i] == null) {
        this.flag = false;
      }
    }

    if (this.flag && this.vflag) {
      if (this.isNew) {
        window.alert("Login Successfully");
      } else {
        window.alert("incorrect username and password");
      }
      this.logForm.reset();
    } else {
      this.alertText = "Please provide Valid Inputs";
    }
  }

  ngOnInit() {}
}
