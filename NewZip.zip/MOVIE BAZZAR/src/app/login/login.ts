export const r_Fields = [
  {
    name: "Email",
    id: "mail",
    type: "email"
  },
  {
    name: "Password",
    id: "pass",
    type: "pass"
  }
];
